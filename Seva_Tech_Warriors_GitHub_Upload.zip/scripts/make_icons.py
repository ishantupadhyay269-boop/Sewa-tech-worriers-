"""Generate Android launcher icons from www/icon-512.png into android/app/src/main/res."""
import os, glob
from PIL import Image

SRC = "www/icon-512.png"
RES = "android/app/src/main/res"
SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}

img = Image.open(SRC).convert("RGBA")

# Use legacy PNG launcher icons (remove adaptive-icon XML so the full logo is not cropped)
for xml in glob.glob(f"{RES}/mipmap-anydpi-v26/*.xml"):
    os.remove(xml)

for density, px in SIZES.items():
    d = f"{RES}/mipmap-{density}"
    os.makedirs(d, exist_ok=True)
    resized = img.resize((px, px), Image.LANCZOS)
    for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
        resized.save(f"{d}/{name}")
print("Icons generated")
