"""Add the permissions the app needs (location, camera) to the generated AndroidManifest."""
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
add = """
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.front" android:required="false" />
"""
if "ACCESS_FINE_LOCATION" not in s:
    s = s.replace("</manifest>", add + "</manifest>")
    open(p, "w", encoding="utf-8").write(s)
print("Manifest patched")
