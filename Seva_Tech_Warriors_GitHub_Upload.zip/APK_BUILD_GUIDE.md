# GitHub से APK बनाने की गाइड (मुफ़्त)

1. github.com पर नई repository बनाइए (जैसे `seva-tech-warriors`)।
2. इस ज़िप को अपने फ़ोन/कंप्यूटर पर **Extract** कीजिए। GitHub ज़िप को अपने आप नहीं खोलता।
3. repo में **Add file → Upload files** दबाइए और Extract की हुई **सारी फ़ाइलें और फ़ोल्डर** खींचकर डालिए
   (`www`, `scripts`, `.github`, `package.json`, `capacitor.config.json` आदि)। फिर **Commit changes** दबाइए।
4. अगर `.github` फ़ोल्डर अपलोड नहीं हुआ (छिपा फ़ोल्डर है): **Add file → Create new file** दबाइए,
   नाम में `.github/workflows/build-apk.yml` लिखिए, और `WORKFLOW_COPY/build-apk.yml` की पूरी सामग्री चिपकाकर Commit कीजिए।
5. **Actions** टैब में "Build Android APK" अपने आप चलेगा (न चले तो "Run workflow" दबाइए)। 5-8 मिनट लगते हैं।
6. रन पूरा होने पर नीचे **Artifacts → Seva-Tech-Warriors-APK** डाउनलोड कीजिए, ज़िप खोलिए और `Seva-Tech-Warriors.apk` फ़ोन में इंस्टॉल कीजिए
   (सेटिंग्स में "Install unknown apps" की अनुमति देनी होगी)।

## ज़रूरी
- `www/index.html` में अपना Firebase `cfg` डालना न भूलें (README.md का चरण 3)।
- Firebase Console → Authentication → Settings → Authorized domains में `localhost` होना चाहिए (डिफ़ॉल्ट में होता है)।
- यह debug-signed APK है: टेस्टिंग और सीधे शेयर करने के लिए ठीक है। Play Store के लिए signed release चाहिए।
- वेब कोड बदलना हो तो सिर्फ़ `www/` के अंदर बदलिए और दोबारा अपलोड कीजिए, नया APK बन जाएगा।

## सीमाएँ (Android WebView)
- बैकग्राउंड पुश नोटिफ़िकेशन, सायरन और फ़्लैशलाइट अभी नहीं हैं।
- फ़ोन की Share शीट (`navigator.share`) WebView में काम नहीं करती।
